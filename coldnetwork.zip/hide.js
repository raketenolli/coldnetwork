const hide = [
    "div#hot-network-questions",
    "div.community-bulletin",
    "div#hireme",
    "div._jobs",
    "div.sidebar-related"
]
hide.forEach(function(selector) { 
    elements = document.querySelectorAll(selector)
    elements.forEach(function(element) {
        element.style.display = "none"
    })
})
